package com.example.minigithub.remote

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Kelas yang mengkonfigurasi Retrofit untuk mengakses layanan GitHub API.
 */
class ApiConfig {
    companion object {
        /**
         * Mendapatkan instance dari [GithubApiService] dengan konfigurasi Retrofit yang sesuai.
         *
         * @return Instance dari [GithubApiService].
         */
        fun getApiService(): GithubApiService {
            // Interceptor untuk menambahkan header Authorization ke setiap permintaan HTTP.
            val authInterceptor = Interceptor { chain ->
                val req = chain.request()
                val requestHeaders = req.newBuilder()
                    .addHeader("Authorization", "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")
                    .build()
                chain.proceed(requestHeaders)
            }

            // Membangun klien OkHttpClient dengan interceptor.
            val client = OkHttpClient.Builder()
                .addInterceptor(authInterceptor)
                .build()

            // Membangun Retrofit instance dengan konfigurasi dasar.
            val retrofit = Retrofit.Builder()
                .baseUrl("https://api.github.com/") // Base URL dari GitHub API.
                .addConverterFactory(GsonConverterFactory.create()) // Konverter Gson.
                .client(client) // Menambahkan OkHttpClient ke Retrofit.
                .build()

            // Membuat instance dari GithubApiService.
            return retrofit.create(GithubApiService::class.java)
        }
    }
}
