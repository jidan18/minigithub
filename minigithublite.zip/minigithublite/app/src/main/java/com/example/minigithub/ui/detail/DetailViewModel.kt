package com.example.minigithub.ui.detail

import android.util.Log
import androidx.lifecycle.*
import com.example.minigithub.data.FavoriteRepository
import com.example.minigithub.data.FavoriteEntity
import com.example.minigithub.model.UserDetailResponse
import com.example.minigithub.remote.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailViewModel(private val favoriteRepository: FavoriteRepository) : ViewModel() {

    // LiveData untuk menyimpan data detail pengguna
    private val _detailUser = MutableLiveData<UserDetailResponse>()
    val detailUser: LiveData<UserDetailResponse> = _detailUser

    // LiveData untuk melacak status loading
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    // Fungsi untuk memasukkan pengguna ke daftar favorit
    fun insert(user: FavoriteEntity) {
        favoriteRepository.insert(user)
    }

    // Fungsi untuk menghapus pengguna dari daftar favorit
    fun delete(user: FavoriteEntity) {
        favoriteRepository.delete(user)
    }

    // Fungsi untuk mencari pengguna favorit berdasarkan username
    fun findUserByUsername(username: String) = favoriteRepository.getFavoriteUserByUsername(username)

    // Fungsi untuk mencari data detail pengguna dari API
    fun findData(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getDetailUser(username)
        client.enqueue(object : Callback<UserDetailResponse> {
            override fun onResponse(call: Call<UserDetailResponse>, response: Response<UserDetailResponse>) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        // Memperbarui LiveData detailUser dengan data hasil panggilan API
                        _detailUser.value = (responseBody)
                    }
                } else {
                    Log.e(DetailActivity.TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<UserDetailResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(DetailActivity.TAG, "onFailure: ${t.message}")
            }
        })
    }
}
