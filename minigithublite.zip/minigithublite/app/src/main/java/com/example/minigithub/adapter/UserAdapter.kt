package com.example.minigithub.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.minigithub.ui.detail.DetailActivity
import com.example.minigithub.ItemsItem
import com.example.minigithub.R

class UserAdapter(private val listUser: List<ItemsItem>) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {

    // Membuat ViewHolder untuk setiap item dalam RecyclerView.
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.user_list, viewGroup, false)
        return ViewHolder(view)
    }

    // Menghubungkan data ke ViewHolder dan menangani klik item.
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
        val getAccount = listUser[position]
        viewHolder.tvAccount.text = getAccount.login

        // Menggunakan Glide untuk memuat gambar dari URL ke ImageView.
        Glide.with(viewHolder.itemView)
            .load(getAccount.avatarUrl)
            .into(viewHolder.tvImage)

        viewHolder.itemView.setOnClickListener {
            val goDetail = Intent(viewHolder.itemView.context, DetailActivity::class.java)

            // Mengirim data ke DetailActivity melalui Intent.
            goDetail.putExtra("Data", getAccount.login)
            viewHolder.itemView.context.startActivity(goDetail)

            // Menampilkan pesan Toast ketika item diklik.
            Toast.makeText(
                viewHolder.itemView.context,
                "Kamu memilih " + listUser[viewHolder.adapterPosition].login,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // Mengembalikan jumlah item dalam RecyclerView.
    override fun getItemCount() = listUser.size

    // ViewHolder untuk menginisialisasi dan mengakses elemen dalam setiap item.
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvImage: ImageView = view.findViewById(R.id.img_avatar)
        val tvAccount: TextView = view.findViewById(R.id.tv_name)
    }
}
