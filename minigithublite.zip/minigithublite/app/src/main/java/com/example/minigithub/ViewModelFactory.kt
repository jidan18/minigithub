package com.example.minigithub

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.minigithub.data.FavoriteRepository
import com.example.minigithub.ui.detail.DetailViewModel
import com.example.minigithub.ui.favorite.FavoriteViewModel
import com.example.minigithub.ui.main.MainViewModel
import com.example.minigithub.ui.theme.SettingPreference
import com.example.minigithub.ui.theme.ThemeViewModel

/**
 * `ViewModelFactory` adalah kelas yang digunakan untuk menyediakan instance ViewModel
 * dengan menginjeksi dependensi yang diperlukan.
 *
 * @param noteRepository Instance dari [FavoriteRepository] yang digunakan dalam ViewModel.
 * @param pref Instance dari [SettingPreference] yang digunakan dalam ViewModel.
 */
class ViewModelFactory private constructor(private val noteRepository: FavoriteRepository, private val pref: SettingPreference) :
    ViewModelProvider.NewInstanceFactory() {

    /**
     * Metode untuk membuat instance ViewModel sesuai dengan tipe kelas yang diberikan.
     *
     * @param modelClass Tipe kelas ViewModel yang akan dibuat.
     * @return Instance ViewModel yang sesuai.
     */
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DetailViewModel::class.java)) {
            return DetailViewModel(noteRepository) as T
        }
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(pref) as T
        }
        if (modelClass.isAssignableFrom(FavoriteViewModel::class.java)) {
            return FavoriteViewModel(noteRepository) as T
        }
        if (modelClass.isAssignableFrom(ThemeViewModel::class.java)) {
            return ThemeViewModel(pref) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }

    companion object {
        @Volatile
        private var INSTANCE: ViewModelFactory? = null

        /**
         * Metode untuk mendapatkan instance tunggal dari [ViewModelFactory].
         *
         * @param context Konteks aplikasi.
         * @return Instance tunggal dari [ViewModelFactory].
         */
        @JvmStatic
        fun getInstance(context: Context): ViewModelFactory {
            if (INSTANCE == null) {
                synchronized(ViewModelFactory::class.java) {
                    INSTANCE = ViewModelFactory(Injection.provideRepository(context), Injection.preference(context))
                }
            }
            return INSTANCE as ViewModelFactory
        }
    }
}
