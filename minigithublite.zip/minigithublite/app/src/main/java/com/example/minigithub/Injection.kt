package com.example.minigithub

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.example.minigithub.data.FavoriteDatabase
import com.example.minigithub.data.FavoriteRepository
import com.example.minigithub.remote.ApiConfig
import com.example.minigithub.ui.theme.SettingPreference

// Ekstensi untuk mengakses DataStore preferensi aplikasi
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "setting")

/**
 * Kelas `Injection` menyediakan metode-metode untuk menginjeksi dependensi dalam aplikasi.
 * Ini termasuk penyediaan repositori favorit dan preferensi tema.
 */
object Injection {

    /**
     * Metode untuk menyediakan instance [FavoriteRepository] dengan menginjeksi dependensi yang diperlukan.
     *
     * @param context Konteks aplikasi.
     * @return Instance [FavoriteRepository].
     */
    fun provideRepository(context: Context): FavoriteRepository {
        val apiService = ApiConfig.getApiService()
        val database = FavoriteDatabase.getDatabase(context)
        val dao = database.favDao()
        return FavoriteRepository(apiService, dao)
    }

    /**
     * Metode untuk menyediakan instance [SettingPreference] dengan menginjeksi DataStore preferensi.
     *
     * @param context Konteks aplikasi.
     * @return Instance [SettingPreference].
     */
    fun preference(context: Context): SettingPreference {
        return SettingPreference.getInstance(context.dataStore)
    }
}
