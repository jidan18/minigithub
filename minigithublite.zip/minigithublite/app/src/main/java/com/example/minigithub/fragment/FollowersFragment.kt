package com.example.minigithub.fragment

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.minigithub.ui.detail.DetailActivity
import com.example.minigithub.ItemsItem
import com.example.minigithub.adapter.UserAdapter
import com.example.minigithub.databinding.FragmentFollowersBinding
import com.example.minigithub.remote.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowersFragment : Fragment() {

    private lateinit var fragmentBinding: FragmentFollowersBinding
    private val adapterBinding get() = fragmentBinding

    private var position: Int? = null
    private var username: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        fragmentBinding = FragmentFollowersBinding.inflate(inflater, container, false)
        return fragmentBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            position = it.getInt(ARG_POSITION)
            username = it.getString(ARG_USERNAME)
        }

        // Konfigurasi layout manager untuk RecyclerView.
        val layoutManager = LinearLayoutManager(requireContext())
        adapterBinding.rvFollowers.layoutManager = layoutManager


        // Memeriksa posisi fragment dan mengambil data yang sesuai dari GitHub.
        when (position) {
            1 -> fetchFollowersData()
            2 -> fetchFollowingData()
        }
    }

    private fun fetchFollowersData() {
        // Menampilkan progress bar saat mengambil data.
        fragmentLoading(true)

        // Memanggil API untuk mendapatkan daftar pengikut.
        val client = ApiConfig.getApiService().getFollowers(username.orEmpty())
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(call: Call<List<ItemsItem>>, response: Response<List<ItemsItem>>) {
                // Menghilangkan progress bar setelah mendapatkan respons.
                fragmentLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    responseBody?.let { followersData(it) }
                } else {
                    // Menampilkan pesan kesalahan jika respons tidak berhasil.
                    Log.e(DetailActivity.TAG, "onFailure : ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                // Menghilangkan progress bar jika ada kegagalan dalam koneksi.
                fragmentLoading(false)
                // Menampilkan pesan kesalahan.
                Log.e(DetailActivity.TAG, "onFailure : ${t.message}")
            }
        })
    }

    private fun fetchFollowingData() {
        // Menampilkan progress bar saat mengambil data.
        fragmentLoading(true)

        // Memanggil API untuk mendapatkan daftar yang diikuti.
        val client = ApiConfig.getApiService().getFollowing(username.orEmpty())
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(call: Call<List<ItemsItem>>, response: Response<List<ItemsItem>>) {
                // Menghilangkan progress bar setelah mendapatkan respons.
                fragmentLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    responseBody?.let { followersData(it) }
                } else {
                    // Menampilkan pesan kesalahan jika respons tidak berhasil.
                    Log.e(DetailActivity.TAG, "onFailure : ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                // Menghilangkan progress bar jika ada kegagalan dalam koneksi.
                fragmentLoading(false)
                // Menampilkan pesan kesalahan.
                Log.e(DetailActivity.TAG, "onFailure : ${t.message}")
            }
        })
    }

    private fun followersData(listUser: List<ItemsItem>) {
        // Menginisialisasi adapter dan menambahkannya ke RecyclerView.
        val adapter = UserAdapter(listUser)
        adapterBinding.rvFollowers.adapter = adapter
    }

    private fun fragmentLoading(isLoading: Boolean) {
        // Mengatur visibilitas progress bar sesuai dengan status isLoading.
        adapterBinding.progressBar3.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val ARG_POSITION = "section_number"
        const val ARG_USERNAME = "name"
    }
}
