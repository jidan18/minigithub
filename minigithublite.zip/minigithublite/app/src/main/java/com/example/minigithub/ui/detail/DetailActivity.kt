package com.example.minigithub.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.view.View.OnClickListener
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.minigithub.R
import com.example.minigithub.ViewModelFactory
import com.example.minigithub.adapter.SectionsPagerAdapter
import com.example.minigithub.databinding.ActivityDetailBinding
import com.example.minigithub.model.UserDetailResponse
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity(), OnClickListener {

    private lateinit var userBinding: ActivityDetailBinding
    private val detailViewModel by viewModels<DetailViewModel>() {
        ViewModelFactory.getInstance(this)
    }

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )

        const val TAG = "DetailActivity"
        const val KEY = "Data"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        userBinding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(userBinding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Inisialisasi adapter untuk tampilan tab
        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)

        // Mengambil username dari intent
        sectionsPagerAdapter.username = intent.getStringExtra(KEY).toString()

        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)

        // Menghubungkan tab layout dengan view pager
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f

        val username = intent.getStringExtra(KEY)

        // Memanggil fungsi findData untuk mendapatkan detail pengguna
        if (username != null) {
            detailViewModel.findData(username)
        }

        // Mengamati perubahan data detail pengguna
        detailViewModel.detailUser.observe(this) { detail ->
            detailData(detail)
        }

        // Mengamati perubahan status isLoading
        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }
    }

    // Fungsi untuk menampilkan data detail pengguna
    private fun detailData(detail: UserDetailResponse) {
        userBinding.apply {
            tvUsername.text = detail.login
            tvName.text = detail.name
            tvFollower.text = resources.getString(R.string.follower_count, detail.followers)
            tvFollowing.text = resources.getString(R.string.following_count, detail.following)
            Glide.with(this@DetailActivity)
                .load(detail.avatarUrl)
                .into(photoDetail)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    // Fungsi untuk menampilkan atau menyembunyikan loading indicator
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            userBinding.progressBar2.visibility = View.VISIBLE
        } else {
            userBinding.progressBar2.visibility = View.GONE
        }
    }

    override fun onClick(view: View) {
        // Tidak ada tindakan yang diperlukan karena fitur favorit telah dihapus
    }
}
