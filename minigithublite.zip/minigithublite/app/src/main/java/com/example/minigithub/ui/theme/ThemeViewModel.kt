package com.example.minigithub.ui.theme

import androidx.lifecycle.*
import kotlinx.coroutines.launch

/**
 * `ThemeViewModel` adalah kelas ViewModel yang bertanggung jawab untuk mengelola pengaturan tema aplikasi.
 * Ini menyediakan metode untuk mengambil pengaturan tema saat ini dan untuk menyimpan perubahan pengaturan tema.
 *
 * @param pref Instance dari `SettingPreference` yang digunakan untuk mengakses preferensi tema.
 */
class ThemeViewModel(private val pref: SettingPreference) : ViewModel() {

    /**
     * Mengambil pengaturan tema saat ini sebagai [LiveData].
     *
     * @return [LiveData] yang menghasilkan nilai boolean, mewakili apakah mode gelap aktif atau tidak.
     */
    fun getThemeSettings(): LiveData<Boolean> {
        return pref.getThemeSetting().asLiveData()
    }

    /**
     * Menyimpan perubahan pengaturan tema ke DataStore menggunakan [viewModelScope].
     *
     * @param isDarkModeActive Boolean yang menentukan apakah mode gelap aktif atau tidak.
     */
    fun saveThemeSetting(isDarkModeActive: Boolean) {
        viewModelScope.launch {
            pref.saveThemeSetting(isDarkModeActive)
        }
    }
}
