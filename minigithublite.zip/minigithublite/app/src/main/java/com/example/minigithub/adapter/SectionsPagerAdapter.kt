package com.example.minigithub.adapter

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.minigithub.fragment.FollowersFragment

/**
 * Adapter untuk mengelola fragmen pada ViewPager2.
 * @param activity Aktivitas yang menggunakan adapter.
 */
class SectionsPagerAdapter(activity: AppCompatActivity) : FragmentStateAdapter(activity) {

    // Default username, bisa diubah sesuai kebutuhan.
    var username: String = "github"

    /**
     * Membuat dan mengembalikan fragmen untuk halaman yang diberikan.
     * @param position Posisi halaman.
     * @return Instance dari fragmen yang akan ditampilkan.
     */
    override fun createFragment(position: Int): Fragment {
        // Membuat fragment untuk setiap halaman dengan posisi yang sesuai.
        val fragment = FollowersFragment()

        // Mengirimkan data ke fragment menggunakan Bundle.
        fragment.arguments = Bundle().apply {
            putInt(FollowersFragment.ARG_POSITION, position + 1)
            putString(FollowersFragment.ARG_USERNAME, username)
        }

        return fragment
    }

    /**
     * Mengembalikan jumlah total halaman yang akan ditampilkan.
     * @return Jumlah halaman.
     */
    override fun getItemCount(): Int {
        // Mengembalikan jumlah halaman yang ingin ditampilkan.
        return 2 // Ganti dengan jumlah halaman yang diinginkan.
    }
}
