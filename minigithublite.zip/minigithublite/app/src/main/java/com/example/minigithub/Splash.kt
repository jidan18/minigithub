package com.example.minigithub

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.example.minigithub.ui.main.MainActivity

class Splash : AppCompatActivity() {
    private lateinit var handler: Handler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Inisialisasi handler untuk menangani penundaan
        handler = Handler(Looper.getMainLooper())

        // PostDelayed akan menjalankan intent ke MainActivity setelah splashDelay
        handler.postDelayed({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, splashDelay)
    }

    companion object {
        // Menentukan waktu penundaan splash screen dalam milidetik (3 detik)
        private var splashDelay: Long = 3000
    }
}
