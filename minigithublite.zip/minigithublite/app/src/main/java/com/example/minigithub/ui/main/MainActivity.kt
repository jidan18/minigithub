package com.example.minigithub.ui.main

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.minigithub.ItemsItem
import com.example.minigithub.R
import com.example.minigithub.ViewModelFactory
import com.example.minigithub.adapter.UserAdapter
import com.example.minigithub.databinding.ActivityMainBinding

private lateinit var layoutManager: RecyclerView.LayoutManager


class MainActivity : AppCompatActivity() {

    // Deklarasi ViewBinding dan ViewModel
    private lateinit var binding: ActivityMainBinding
    private val mainViewModel by viewModels<MainViewModel>{
        ViewModelFactory.getInstance(this)
    }

    // Deklarasi daftar (list) dan adapter
    private val list = ArrayList<ItemsItem>()
    private val listUserAdapter = UserAdapter(list)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inisialisasi ViewBinding
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Mengatur layout manager dan item decoration pada RecyclerView
        val layoutManager = LinearLayoutManager(this)
        binding.rvUsers.layoutManager = layoutManager


        // Menghubungkan adapter dengan RecyclerView
        binding.rvUsers.adapter = listUserAdapter

        // Mengamati perubahan pada LiveData listUser dan memanggil setUserData untuk memperbarui tampilan
        mainViewModel.listUser.observe(this, {item ->
            setUserData(item)
        })

        // Mengamati perubahan pada LiveData isLoading dan memanggil showLoading untuk menampilkan atau menyembunyikan ProgressBar
        mainViewModel.isLoading.observe(this, {
            showLoading(it)
        })

    }

    // Fungsi untuk membuat menu pada ActionBar
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)

        // Inisialisasi SearchManager dan SearchView
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        // Mengatur SearchableInfo dan hint pada SearchView
        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)

        // Mengamati perubahan pada LiveData searchUser dan mengubah teks pada SearchView
        mainViewModel.searchUser.observe(this) { query ->
            searchView.setQuery(query.toString(), false)
        }

        // Mengamati perubahan tema dan mengubah tema aplikasi
        mainViewModel.getTheme().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

        // Mengatur listener untuk event saat pengguna mengetik pada SearchView
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                mainViewModel.getUser(query)
                searchView.clearFocus()
                return true
            }

            override fun onQueryTextChange(query: String): Boolean {
                mainViewModel.searchUser.postValue(query)
                return false
            }
        })

        return true
    }

    // Fungsi untuk menangani event saat pengguna memilih item pada menu ActionBar
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_list -> {
                layoutManager = LinearLayoutManager(this)
                binding.rvUsers.layoutManager = layoutManager
            }
            R.id.action_grid -> {
                layoutManager = GridLayoutManager(this, 2)
                binding.rvUsers.layoutManager = layoutManager
            }
        }
        return super.onOptionsItemSelected(item)
    }

    // Fungsi untuk mengatur data pengguna pada RecyclerView
    private fun setUserData(listUser: List<ItemsItem>) {
        val listUserAdapter = UserAdapter(listUser)
        binding.rvUsers.adapter = listUserAdapter
    }

    // Fungsi untuk menampilkan atau menyembunyikan ProgressBar
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }


}
