package com.example.minigithub.ui.favorite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.minigithub.ItemsItem
import com.example.minigithub.ViewModelFactory
import com.example.minigithub.adapter.UserAdapter
import com.example.minigithub.data.FavoriteEntity

class FavoriteActivity : AppCompatActivity() {


}
