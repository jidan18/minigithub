package com.example.minigithub.model

import com.google.gson.annotations.SerializedName

// Data class yang mewakili respons JSON dari API GitHub untuk detail pengguna.
data class UserDetailResponse(
    @SerializedName("gists_url") val gistsUrl: String, // URL gists pengguna.
    @SerializedName("repos_url") val reposUrl: String, // URL repositori pengguna.
    @SerializedName("following_url") val followingUrl: String, // URL daftar pengguna yang diikuti.
    @SerializedName("twitter_username") val twitterUsername: Any, // Nama pengguna Twitter (jika ada).
    @SerializedName("bio") val bio: Any, // Bio pengguna (jika ada).
    @SerializedName("created_at") val createdAt: String, // Tanggal pembuatan akun GitHub.
    @SerializedName("login") val login: String, // Nama pengguna GitHub.
    @SerializedName("type") val type: String, // Jenis akun (contoh: "User" atau "Organization").
    @SerializedName("blog") val blog: String, // URL blog pengguna (jika ada).
    @SerializedName("subscriptions_url") val subscriptionsUrl: String, // URL langganan pengguna.
    @SerializedName("updated_at") val updatedAt: String, // Tanggal pembaruan profil GitHub.
    @SerializedName("site_admin") val siteAdmin: Boolean, // Status admin situs.
    @SerializedName("company") val company: String, // Nama perusahaan pengguna (jika ada).
    @SerializedName("id") val id: Int, // ID pengguna GitHub.
    @SerializedName("public_repos") val publicRepos: Int, // Jumlah repositori publik pengguna.
    @SerializedName("gravatar_id") val gravatarId: String, // ID Gravatar pengguna.
    @SerializedName("email") val email: Any, // Alamat email pengguna (jika ada).
    @SerializedName("organizations_url") val organizationsUrl: String, // URL organisasi pengguna.
    @SerializedName("hireable") val hireable: Any, // Status ketersediaan untuk dipekerjakan (jika ada).
    @SerializedName("starred_url") val starredUrl: String, // URL repositori yang ditandai bintang oleh pengguna.
    @SerializedName("followers_url") val followersUrl: String, // URL daftar pengikut pengguna.
    @SerializedName("public_gists") val publicGists: Int, // Jumlah gists publik pengguna.
    @SerializedName("url") val url: String, // URL profil pengguna di GitHub.
    @SerializedName("received_events_url") val receivedEventsUrl: String, // URL peristiwa yang diterima pengguna.
    @SerializedName("followers") val followers: Int, // Jumlah pengikut pengguna.
    @SerializedName("avatar_url") val avatarUrl: String, // URL avatar pengguna.
    @SerializedName("events_url") val eventsUrl: String, // URL peristiwa yang terkait dengan pengguna.
    @SerializedName("html_url") val htmlUrl: String, // URL profil HTML pengguna di GitHub.
    @SerializedName("following") val following: Int, // Jumlah pengguna yang diikuti oleh pengguna.
    @SerializedName("name") val name: String, // Nama lengkap pengguna (jika ada).
    @SerializedName("location") val location: String, // Lokasi pengguna (jika ada).
    @SerializedName("node_id") val nodeId: String // ID node pengguna.
)
