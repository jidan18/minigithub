package com.example.minigithub.ui.theme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.CompoundButton
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate

/**
 * `ThemeActivity` adalah aktivitas yang digunakan untuk mengelola pengaturan tema aplikasi.
 * Pengguna dapat mengaktifkan atau menonaktifkan mode gelap melalui tombol switch yang disediakan.
 */
class ThemeActivity : AppCompatActivity() {

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            android.R.id.home -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
